TOTAL = 0
CSV = ""

def parse(name, ignore = []):
    file = open(name, "r")
    lines = file.readlines()
    out = []
    for l in lines:
        l = l.replace(",", "") #commas are evil
        #print(l)
        l = lineSplitter(l)
        if l == None: #skip noise
                        continue
        if not ignores(l[1], ignore):
            liner = []
            
            for f in l:
                f = f.strip()
                liner.append(f)
        out.append(liner)
    file.close()
    return out

def ignores(line, ignore):
    for i in ignore:
        if i in line:
            return True #ignore
    return False

def lineSplitter(line):
    if not line[0].isdigit():
        return None #no date field means noise
    dateSliceEnd = 0
    priceSliceStart = len(line) -1

    while line[dateSliceEnd] != " ":
        dateSliceEnd += 1
        
    while line[priceSliceStart] != " ":
        priceSliceStart -=1

    slicer1 = line[0:dateSliceEnd]
    slicer2 = line[dateSliceEnd:priceSliceStart]
    slicer3 = line[priceSliceStart:len(line)]


    return [slicer1, slicer2, slicer3]

#tallies up the prices, with an array for ignoring specific substrings
def addup(lines):
    #assuming lines is whatever parse generates
    result = 0

    for line in lines:
        result += float(line[2]) #adds up prices
    out = round(result, 2) #rounding off noise form floating point math

    global TOTAL
    TOTAL += out
    return out


def doFile(file, ignoreList = []):
    global CSV
    p = parse(file + ".txt", ignoreList)
    print("\nFile", file + ":")
    print()
    for line in p:
        print(line[0] + "    " + line[1] + line[2].rjust(50 - len(line[1])))
        CSV += line[0]+","+line[1]+","+line[2]+"\n"

    ignoreString = "\nNothing Ignored"
    if len(ignoreList) > 0:
        ignoreString = "\nIgnoring: "
        for i in ignoreList:
            ignoreString += i + ',  '
    print()
    print("Total for", file, "->", "$" + str(addup(p)), )
    print("========================================")

def main(files):
    for i in files:
        #print(i)
        doFile(i)
    global TOTAL
    print("Grand total: $" +  str(round(TOTAL, 2)))

    global CSV
    f = open("out.csv", "w")
    f.write(CSV)
    f.close()
    print("Written to 'out.csv' for importing to excel")

main(["Generic"])
