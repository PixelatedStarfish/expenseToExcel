So this is a document parser for expense tables. You might be thinking "Most banks will let you download records directly to your computer as a csv. Why do you need this???" Well some banks have not heard of csv files and just give you a webpage and say "good luck". So, I wrote a parser in python. Copy the content of the page to the program input and my parser will give you a csv you can put in excel. This readme also doubles as a test file!

The webpage is pretty noisy too. It includes a lot of text that is not a record of your card activity. Stuff like:

Hey you may be eligible for a promotion from bank!!! Is that awesome?!??!?!? oh yeah!!!

BlahBlah stuff about stuff and card and stuff and a description of a card or something or maybe a disclaimer or who knows right??

Oh 
Wow
Look
At 
Allofthese
Links
toStuffYouDoNotWant


1/1  LUCKYLAND PLAYINGCARDS NT 12.34
1/1  LUCKYLAND PLAYINGCARDS NT 34.21
1/1  LUCKYLAND PLAYINGCARDS NT 23.33
1/1  LUCKYLAND PLAYINGCARDS NT 21.12
1/1  LUCKYLAND PLAYINGCARDS NT 11.11
1/1  LUCKYLAND PLAYINGCARDS NT 3.14
1/1  LUCKYLAND PLAYINGCARDS NT 12.25
1/1  LUCKYLAND PLAYINGCARDS NT 32.23
1/1  LUCKYLAND PLAYINGCARDS NT 3.22
Page 23 nksdvildfkgnsdfj 4324 fkljfsdlif 2334
Oh yeah so despite being online this thing still comes with pagination so you can print it or something. Remember 2005? Remember Mapquest? We have not updated this part of the site since then!
The webpage is pretty noisy too. It includes a lot of text that is not a record of your card activity. Stuff like:

Hey you may be eligible for a promotion from bank!!! Is that awesome?!??!?!? oh yeah!!!

BlahBlah stuff about stuff and card and stuff and a description of a card or something or maybe a disclaimer or who knows right??

Oh 
Wow
Look
At 
Allofthese
Links
toStuffYouDoNotWant

TABLE CONTINUES OH HERES THE TITLE AGAIN LOL
1/1  LUCKYLAND PLAYINGCARDS NT 11.23
1/1  LUCKYLAND PLAYINGCARDS NT 12.34
1/1  LUCKYLAND PLAYINGCARDS NT 34.21
1/1  LUCKYLAND PLAYINGCARDS NT 23.33
1/1  LUCKYLAND PLAYINGCARDS NT 21.12
1/1  LUCKYLAND PLAYINGCARDS NT 11.11
1/1  LUCKYLAND PLAYINGCARDS NT 3.14
Fgsi4ug2ui5g345   330934583450
And I'm here too 342342 004435
X 3240734 8384 394494 What am I? 
WHO CARES???! 93432948 8899000 
1/1  LUCKYLAND PLAYINGCARDS NT 12.25
1/1  LUCKYLAND PLAYINGCARDS NT 32.23
1/1  LUCKYLAND PLAYINGCARDS NT 23.11
1/1  LUCKYLAND PLAYINGCARDS NT 23.23

Hey you may be eligible for a promotion from bank!!! Is that awesome?!??!?!? oh yeah!!!

BlahBlah stuff about stuff and card and stuff and a description of a card or something or maybe a disclaimer or who knows right??

Oh 
Wow
Look
At 
Allofthese
Links
toStuffYouDoNotWant